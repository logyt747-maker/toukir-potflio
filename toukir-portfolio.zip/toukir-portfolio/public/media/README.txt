MEDIA FOLDER
- background.mp4 : the looping background video (1080p, no sound). Replace it with another mp4 to change the background.
- song.mp3       : the music (taken from the video's audio). Replace it, or add more songs in data.json -> "music".
If background.mp4 is missing, an animated aurora background is shown instead.
Use only music and video you have the rights to use, especially if the site is public.
