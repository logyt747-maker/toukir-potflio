const $ = (id) => document.getElementById(id);
const el = (tag, text, cls) => {
  const e = document.createElement(tag);
  if (text !== undefined && text !== "") e.textContent = text;
  if (cls) e.className = cls;
  return e;
};
const link = (text, href, external = true) => {
  const a = el("a", text);
  a.href = href;
  if (external) { a.target = "_blank"; a.rel = "noopener"; }
  return a;
};
const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;

function typeRoles(roles) {
  const out = $("typed");
  if (reduced) { out.textContent = roles[0]; return; }
  let r = 0, i = 0, del = false;
  (function tick() {
    const w = roles[r];
    out.textContent = w.slice(0, i);
    let delay = del ? 40 : 85;
    if (!del && i === w.length) { del = true; delay = 1500; }
    else if (del && i === 0) { del = false; r = (r + 1) % roles.length; delay = 350; }
    else i += del ? -1 : 1;
    setTimeout(tick, delay);
  })();
}

function countUp(node, to) {
  if (reduced) { node.textContent = to + "+"; return; }
  const t0 = performance.now();
  (function step(t) {
    const p = Math.min((t - t0) / 1400, 1);
    node.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))) + (p === 1 ? "+" : "");
    if (p < 1) requestAnimationFrame(step);
  })(t0);
}

// Editor-style code card built from the profile data
function buildCode(d, stack) {
  const lines = [
    [["c", "// my profile"]],
    [["k", "const "], ["", "developer = {"]],
    [["", "  name: "], ["s", '"' + d.name + '"'], ["", ","]],
    [["", "  role: "], ["s", '"' + d.roles[0] + '"'], ["", ","]],
    [["", "  location: "], ["s", '"' + d.location + '"'], ["", ","]],
    [["", "  stack: ["], ["s", stack.map((x) => '"' + x + '"').join(", ")], ["", "],"]],
    [["", "  openToWork: "], ["b", "true"], ["", ","]],
    [["", "};"]],
  ];
  lines.forEach((parts) => {
    parts.forEach(([cls, txt]) => $("code").appendChild(el("span", txt, cls)));
    $("code").appendChild(document.createTextNode("\n"));
  });
}

function setupUI() {
  // scroll progress bar
  addEventListener("scroll", () => {
    const h = document.documentElement;
    $("progress").style.width = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100 + "%";
    $("bg").style.setProperty("--sa", Math.min(0.8, 0.3 + (h.scrollTop / innerHeight) * 0.5).toFixed(2));
  }, { passive: true });

  // mobile menu
  const toggle = (open) => {
    $("menu").classList.toggle("open", open);
    $("burger").setAttribute("aria-expanded", open);
  };
  $("burger").addEventListener("click", () => toggle(!$("menu").classList.contains("open")));
  $("menu").addEventListener("click", (e) => { if (e.target.tagName === "A") toggle(false); });

  // reveal sections + fill skill bars
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add("in");
      e.target.querySelectorAll(".bar-bg span").forEach((b) => (b.style.width = b.dataset.level + "%"));
      io.unobserve(e.target);
    });
  }, { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach((s) => io.observe(s));

  // highlight current menu link
  const links = [...document.querySelectorAll("#menu a")];
  const spy = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) links.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === "#" + e.target.id));
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  document.querySelectorAll("section[id]").forEach((s) => spy.observe(s));
}

fetch("/api/profile")
  .then((r) => r.json())
  .then((d) => {
    document.title = d.name + " - " + d.title;
    $("name").textContent = d.name;
    $("intro").textContent = d.intro;
    $("loc").textContent = d.location;
    $("photo").src = d.photo || "profile.jpg";
    $("photo").alt = d.name;

    d.about.forEach((t) => $("aboutText").appendChild(el("p", t)));

    const allSkills = d.skillGroups.flatMap((g) => g.items.map((s) => s.name));
    buildCode(d, d.skillGroups[1].items.slice(0, 3).map((s) => s.name));

    // hero stats (counted from the data below, so they are always true)
    [["Technologies", allSkills.length], ["Services", d.services.length], ["Projects", d.projects.length]].forEach(([label, n]) => {
      const box = el("div", "", "stat");
      const b = el("b", "0");
      box.appendChild(b);
      box.appendChild(el("span", label));
      $("stats").appendChild(box);
      countUp(b, n);
    });

    d.services.forEach((s, i) => {
      const c = el("article", "", "card");
      c.appendChild(el("span", "◈", "num icon"));
      c.appendChild(el("h3", s.title));
      c.appendChild(el("p", s.text));
      $("serviceList").appendChild(c);
    });

    // scrolling technology strip (list repeated for a seamless loop)
    [...allSkills, ...allSkills].forEach((n) => $("track").appendChild(el("span", n)));

    d.skillGroups.forEach((g) => {
      const box = el("div", "", "card");
      box.appendChild(el("h3", g.group));
      g.items.forEach((s) => {
        const wrap = el("div", "", "skill");
        const row = el("div", "", "row");
        row.appendChild(el("span", s.name));
        row.appendChild(el("span", s.level + "%", "pct"));
        const bg = el("div", "", "bar-bg");
        const fill = el("span");
        fill.dataset.level = s.level;
        bg.appendChild(fill);
        wrap.appendChild(row);
        wrap.appendChild(bg);
        box.appendChild(wrap);
      });
      $("skillGroups").appendChild(box);
    });
    d.softSkills.forEach((s) => $("soft").appendChild(el("li", s)));

    d.workflow.forEach((s, i) => {
      const c = el("article", "", "card");
      c.dataset.n = String(i + 1).padStart(2, "0");
      c.appendChild(el("span", "Step " + (i + 1), "num"));
      c.appendChild(el("h3", s.title));
      c.appendChild(el("p", s.text));
      $("steps").appendChild(c);
    });

    // category filter chips
    ["All", ...new Set(d.projects.map((p) => p.category))].forEach((cat, i) => {
      const chip = el("button", cat, "chip" + (i === 0 ? " on" : ""));
      chip.type = "button";
      chip.addEventListener("click", () => {
        document.querySelectorAll("#filters .chip").forEach((x) => x.classList.toggle("on", x === chip));
        document.querySelectorAll("#projectList .project").forEach((c) => (c.hidden = cat !== "All" && c.dataset.cat !== cat));
      });
      $("filters").appendChild(chip);
    });

    d.projects.forEach((p) => {
      const c = el("article", "", "card project");
      c.dataset.cat = p.category;
      c.appendChild(el("div", p.icon || "◆", "thumb"));
      const body = el("div", "", "body");
      body.appendChild(el("span", p.category, "num"));
      body.appendChild(el("h3", p.name));
      body.appendChild(el("p", p.description));
      const feat = el("ul", "", "feat");
      (p.features || []).forEach((f) => feat.appendChild(el("li", f)));
      body.appendChild(feat);
      const tags = el("ul", "", "tags");
      p.tech.forEach((t) => tags.appendChild(el("li", t)));
      body.appendChild(tags);
      const act = el("div", "", "proj-actions");
      if (p.demo) {
        const live = el("button", "▶ Live demo", "btn primary sm");
        live.type = "button";
        live.addEventListener("click", () => openDemo(p));
        act.appendChild(live);
        act.appendChild(link("Open in new tab ↗", p.demo, true));
      } else if (p.link) act.appendChild(link("View project →", p.link));
      body.appendChild(act);
      c.appendChild(body);
      $("projectList").appendChild(c);
    });

    const c = d.contact;
    const add = (label, node) => {
      const li = el("li");
      li.appendChild(el("b", label));
      li.appendChild(node);
      $("contactList").appendChild(li);
    };
    if (c.email) add("Email", link(c.email, "mailto:" + c.email, false));
    if (c.facebook) add("Facebook", link("facebook.com/toukirofficial01", c.facebook));
    if (c.discord) add("Discord", link(c.discord.replace(/^https?:\/\//, ""), c.discord));
    if (c.github) add("GitHub", link(c.github, c.github));
    add("Location", el("span", d.location));

    [["Facebook", c.facebook], ["Discord", c.discord], ["GitHub", c.github], ["Email", c.email && "mailto:" + c.email]]
      .filter(([, h]) => h)
      .forEach(([n, h]) => $("footLinks").appendChild(link(n, h, !h.startsWith("mailto"))));
    $("foot").textContent = "© " + new Date().getFullYear() + " " + d.name + ". All rights reserved.";

    typeRoles(d.roles);
    setupUI();
    initExtras(d);
    buildStatus(d);
  })
  .catch(() => ($("name").textContent = "Could not load data.json"));

// Contact form
$("contactForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target, msg = $("formMsg"), btn = form.querySelector("button");
  msg.className = "";
  msg.textContent = "Sending...";
  btn.disabled = true;
  try {
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(new FormData(form))),
    });
    const out = await res.json();
    if (out.ok) { msg.className = "ok"; msg.textContent = "Message sent. Thank you, I'll reply soon!"; form.reset(); }
    else { msg.className = "err"; msg.textContent = out.error || "Something went wrong."; }
  } catch {
    msg.className = "err"; msg.textContent = "Could not send. Please try again.";
  }
  btn.disabled = false;
});

// ---- Live demo window ----
function openDemo(p) {
  $("modalTitle").textContent = p.name + " - live demo";
  $("modalOpen").href = p.demo;
  $("frame").src = p.demo;
  $("modal").hidden = false;
  document.body.style.overflow = "hidden";
  $("modalClose").focus();
}
function closeDemo() {
  $("modal").hidden = true;
  $("frame").src = "about:blank";
  document.body.style.overflow = "";
}
$("modalClose").addEventListener("click", closeDemo);
$("modal").addEventListener("click", (e) => { if (e.target === $("modal")) closeDemo(); });
addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("modal").hidden) closeDemo(); });

// ---- Card spotlight that follows the mouse ----
document.addEventListener("mousemove", (e) => {
  const c = e.target.closest && e.target.closest(".card");
  if (!c) return;
  const r = c.getBoundingClientRect();
  c.style.setProperty("--mx", e.clientX - r.left + "px");
  c.style.setProperty("--my", e.clientY - r.top + "px");
});

// ---- Back to top ----
addEventListener("scroll", () => $("toTop").classList.toggle("show", scrollY > 700), { passive: true });
$("toTop").addEventListener("click", () => scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" }));

// ---- Hero network animation ----
(function () {
  const cv = $("net");
  if (!cv || reduced) return;
  const ctx = cv.getContext("2d");
  let W, H, pts = [];
  function size() {
    W = cv.width = cv.offsetWidth; H = cv.height = cv.offsetHeight;
    pts = Array.from({ length: Math.min(70, Math.floor(W / 16)) }, () => ({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35 }));
  }
  size();
  addEventListener("resize", size);
  (function draw() {
    requestAnimationFrame(draw);
    if (document.hidden || scrollY > H) return;
    ctx.clearRect(0, 0, W, H);
    pts.forEach((p) => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;
      ctx.fillStyle = "rgba(39,217,245,.75)";
      ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, 7); ctx.fill();
    });
    for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
      const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y, dist = Math.hypot(dx, dy);
      if (dist < 130) {
        ctx.strokeStyle = "rgba(39,217,245," + (1 - dist / 130) * .28 + ")";
        ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke();
      }
    }
  })();
})();

// =============== Intro screen, video, music, location, views ===============
let entered = false, startMedia = () => {};
function enter() {
  if (entered) return;
  entered = true;
  $("splash").classList.add("out");
  document.body.classList.remove("locked");
  document.body.classList.add("entered");
  setTimeout(() => { const sp = $("splash"); if (sp) sp.remove(); }, 1000);
  startMedia();
}
$("splash").addEventListener("click", enter);
document.querySelectorAll(".hero-text > *").forEach((n, i) => n.style.setProperty("--i", i));

// custom cursor + hero 3D tilt (mouse devices only)
if (!reduced && !matchMedia("(pointer: coarse)").matches) {
  const ring = $("ring"), glow = $("glowCursor");
  let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y;
  addEventListener("mousemove", (e) => {
    x = e.clientX; y = e.clientY;
    glow.style.transform = "translate(" + x + "px," + y + "px)";
    ring.classList.toggle("big", !!(e.target.closest && e.target.closest("a, button, .chip, input, textarea")));
  });
  (function loop() {
    rx += (x - rx) * 0.18; ry += (y - ry) * 0.18;
    ring.style.transform = "translate(" + rx + "px," + ry + "px)";
    requestAnimationFrame(loop);
  })();
  const hp = document.querySelector(".hero-photo");
  document.querySelector(".hero").addEventListener("mousemove", (e) => {
    const r = hp.getBoundingClientRect();
    hp.style.setProperty("--ry", ((e.clientX - r.left - r.width / 2) / innerWidth) * 24 + "deg");
    hp.style.setProperty("--rx", (-(e.clientY - r.top - r.height / 2) / innerHeight) * 24 + "deg");
  });
}

const SVG = (inner, extra = "") => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" ' + extra + ">" + inner + "</svg>";
const ICON = {
  facebook: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.77l-.44 2.89h-2.33v6.99A10 10 0 0 0 22 12z"/></svg>',
  discord: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.74 19.74 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.1 13.1 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.292a.074.074 0 0 1 .078-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .079.009c.12.1.246.198.373.293a.077.077 0 0 1-.006.127 12.3 12.3 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.84 19.84 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>',
  mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>',
  github: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 6l-6 6 6 6M16 6l6 6-6 6"/></svg>',
};
const I = {
  play: SVG('<path d="M8 5v14l11-7z"/>'),
  pause: SVG('<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>'),
  prev: SVG('<path d="M6 5h2v14H6zM20 5v14L9 12z"/>'),
  next: SVG('<path d="M16 5h2v14h-2zM4 5v14l11-7z"/>'),
  vol: SVG('<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a9 9 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
  mute: SVG('<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'),
};
const mmss = (t) => (isFinite(t) ? Math.floor(t / 60) + ":" + String(Math.floor(t % 60)).padStart(2, "0") : "0:00");

function initExtras(d) {
  $("sName").textContent = d.name;
  $("sName").dataset.text = d.name;
  $("name").dataset.text = d.name;

  // live local time for the location
  try {
    const fmt = new Intl.DateTimeFormat("en-US", { timeZone: d.timezone || "Asia/Dhaka", hour: "numeric", minute: "2-digit", second: "2-digit" });
    const tick = () => ($("clock").textContent = "Local time " + fmt.format(new Date()));
    tick(); setInterval(tick, 1000);
  } catch { $("clock").remove(); }

  // social icon buttons
  const c = d.contact;
  const mk = (k, label, node) => {
    node.innerHTML = ICON[k]; // fixed icon strings only
    node.title = label; node.setAttribute("aria-label", label);
    $("socials").appendChild(node);
  };
  if (c.facebook) mk("facebook", "Facebook", link("", c.facebook));
  if (c.discord) mk("discord", "Discord", link("", c.discord));
  if (c.email) mk("mail", "Email", link("", "mailto:" + c.email, false));
  if (c.github) mk("github", "GitHub", link("", c.github));

  // visitor counter (counts a visitor once every 6 hours)
  let fresh = true;
  try { fresh = Date.now() - (+localStorage.getItem("viewTs") || 0) > 6 * 3600 * 1000; } catch {}
  fetch("/api/views", { method: fresh ? "POST" : "GET" }).then((r) => r.json()).then((v) => {
    $("views").textContent = Number(v.views).toLocaleString("en-US");
    try { localStorage.setItem("viewTs", Date.now()); } catch {}
  }).catch(() => {});

  // background video (falls back to the animated aurora if the file is missing)
  const vid = $("bgVideo");
  if (d.video) {
    fetch(d.video, { method: "HEAD" }).then((r) => {
      if (!r.ok) return;
      vid.src = d.video;
      vid.addEventListener("canplay", () => vid.classList.add("on"), { once: true });
      if (entered) vid.play().catch(() => {});
    }).catch(() => {});
  }

  // music player
  const tracks = d.music || [];
  if (!tracks.length) { $("player").remove(); startMedia = () => vid.play().catch(() => {}); if (entered) startMedia(); return; }
  const audio = new Audio();
  audio.preload = "auto";
  audio.loop = tracks.length === 1;
  let idx = 0, actx = null, analyser = null, buf = null;
  $("pPrev").innerHTML = I.prev; $("pNext").innerHTML = I.next; $("pPlay").innerHTML = I.play; $("pMute").innerHTML = I.vol;

  function load(i) {
    idx = (i + tracks.length) % tracks.length;
    const t = tracks[idx];
    audio.src = t.src;
    $("pTitle").textContent = t.title;
    $("pArtist").textContent = t.artist || "";
    $("pCover").src = t.cover || d.photo;
  }
  function setPlaying(on) {
    $("pPlay").innerHTML = on ? I.pause : I.play;
    $("player").classList.toggle("playing", on);
  }
  function play() {
    try {
      if (!actx) {
        actx = new (window.AudioContext || window.webkitAudioContext)();
        analyser = actx.createAnalyser(); analyser.fftSize = 64;
        buf = new Uint8Array(analyser.frequencyBinCount);
        actx.createMediaElementSource(audio).connect(analyser);
        analyser.connect(actx.destination);
      }
      if (actx.state === "suspended") actx.resume();
    } catch { analyser = null; }
    return audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  }
  load(0);
  audio.addEventListener("loadedmetadata", () => ($("pDur").textContent = mmss(audio.duration)));
  audio.addEventListener("timeupdate", () => {
    $("pCur").textContent = mmss(audio.currentTime);
    if (audio.duration) $("pSeek").value = (audio.currentTime / audio.duration) * 1000;
  });
  audio.addEventListener("ended", () => { if (tracks.length > 1) { load(idx + 1); play(); } else setPlaying(false); });
  audio.addEventListener("error", () => { $("player").hidden = true; });
  $("pSeek").addEventListener("input", () => { if (audio.duration) audio.currentTime = ($("pSeek").value / 1000) * audio.duration; });
  $("pPlay").addEventListener("click", () => (audio.paused ? play() : (audio.pause(), setPlaying(false))));
  $("pPrev").addEventListener("click", () => { load(idx - 1); play(); });
  $("pNext").addEventListener("click", () => { load(idx + 1); play(); });
  $("pMute").addEventListener("click", () => { audio.muted = !audio.muted; $("pMute").innerHTML = audio.muted ? I.mute : I.vol; });

  // equalizer bars
  const vc = $("viz"), vx = vc.getContext("2d");
  (function drawViz() {
    requestAnimationFrame(drawViz);
    vx.clearRect(0, 0, vc.width, vc.height);
    if (audio.paused) return;
    const n = 10, bw = vc.width / n;
    if (analyser) analyser.getByteFrequencyData(buf);
    for (let i = 0; i < n; i++) {
      const v = analyser ? buf[i + 1] / 255 : 0.3 + 0.3 * Math.sin(Date.now() / 160 + i);
      const h = Math.max(3, v * vc.height);
      vx.fillStyle = "#27d9f5";
      vx.fillRect(i * bw + 1, vc.height - h, bw - 3, h);
    }
  })();

  startMedia = () => {
    $("player").hidden = false;
    vid.play().catch(() => {});
    play();
  };
  if (entered) startMedia();
}

// =============== System Status Window + notifications ===============
function buildStatus(d) {
  $("sName2").textContent = d.name;
  $("sJob").textContent = d.status.class;
  $("sArea").textContent = d.location.split(",")[0];
  const skills = d.skillGroups.reduce((n, g) => n + g.items.length, 0);
  const stats = d.skillGroups.map((g) => ({ name: g.group.toUpperCase(), v: Math.round(g.items.reduce((a, s) => a + s.level, 0) / g.items.length) }));
  stats.forEach((s) => {
    const box = el("div", "", "stt");
    const row = el("div", "", "row");
    row.appendChild(el("span", s.name));
    row.appendChild(el("b", String(s.v)));
    const tr = el("div", "", "track2");
    const f = el("span");
    f.dataset.v = s.v;
    tr.appendChild(f);
    box.appendChild(row);
    box.appendChild(tr);
    $("sysStats").appendChild(box);
  });
  // fill bars and count numbers once the page has been entered
  const run = () => {
    document.querySelectorAll("#sysStats .track2 span").forEach((f) => (f.style.width = f.dataset.v + "%"));
    const count = (node, to) => {
      const t0 = performance.now();
      (function step(t) {
        const p = Math.min((t - t0) / 1500, 1);
        node.textContent = Math.round(to * p);
        if (p < 1) requestAnimationFrame(step);
      })(t0);
    };
    count($("sLevel"), d.level);
    count($("sSkills"), skills);
    count($("sProj"), d.projects.length);
    setTimeout(() => toast("SYSTEM", "Welcome, Player. Portfolio loaded."), 1300);
    setTimeout(() => toast("NEW QUEST", "Explore the projects and try the live demos."), 3300);
  };
  const wait = setInterval(() => { if (entered) { clearInterval(wait); setTimeout(run, 500); } }, 100);
}
function toast(title, text) {
  const t = el("div", "", "toast");
  t.appendChild(el("small", "[ " + title + " ]"));
  t.appendChild(el("span", text));
  const close = () => { t.classList.add("out"); setTimeout(() => t.remove(), 400); };
  t.addEventListener("click", close);
  $("toasts").appendChild(t);
  setTimeout(close, 5500);
}
