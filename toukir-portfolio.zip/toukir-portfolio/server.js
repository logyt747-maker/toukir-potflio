// Portfolio server - only built-in Node.js modules, no npm install needed.
const http = require("http");
const fs = require("fs");
const path = require("path");
const tls = require("tls");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const MESSAGES = path.join(__dirname, "messages.json");
const TYPES = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml",
  ".mp4": "video/mp4", ".webm": "video/webm", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".ogg": "audio/ogg", ".woff2": "font/woff2",
};

// Spam limit: max 5 messages per minute per visitor
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60000);
  list.push(now);
  hits.set(ip, list);
  return list.length > 5;
}

function sendJSON(res, code, obj) {
  res.writeHead(code, { "Content-Type": TYPES[".json"] });
  res.end(JSON.stringify(obj));
}

function loadConfig() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8")); } catch { return {}; }
}

// Minimal Gmail SMTP client (smtp.gmail.com:465, needs a Google "App Password")
function sendMail({ user, pass, to, replyTo, subject, text }) {
  return new Promise((resolve, reject) => {
    const b64 = (s) => Buffer.from(s, "utf8").toString("base64");
    const body = b64(text).replace(/(.{76})/g, "$1\r\n");
    const msg = [
      "From: Portfolio Contact <" + user + ">", "To: " + to, "Reply-To: " + replyTo,
      "Subject: =?UTF-8?B?" + b64(subject) + "?=", "MIME-Version: 1.0",
      "Content-Type: text/plain; charset=utf-8", "Content-Transfer-Encoding: base64", "", body,
    ].join("\r\n");
    const expect = [220, 250, 334, 334, 235, 250, 250, 354, 250];
    const send = ["EHLO localhost", "AUTH LOGIN", b64(user), b64(pass), "MAIL FROM:<" + user + ">", "RCPT TO:<" + to + ">", "DATA", msg];
    const sock = tls.connect(465, "smtp.gmail.com", { servername: "smtp.gmail.com" });
    let buf = "", i = 0;
    sock.setTimeout(20000, () => { sock.destroy(); reject(new Error("timeout")); });
    sock.on("error", reject);
    sock.on("data", (chunk) => {
      buf += chunk;
      const lines = buf.trimEnd().split(/\r?\n/);
      if (!/\r?\n$/.test(buf) || !/^\d{3} /.test(lines[lines.length - 1])) return;
      const code = +lines[lines.length - 1].slice(0, 3);
      buf = "";
      if (code !== expect[i]) { sock.destroy(); return reject(new Error("SMTP " + lines.join(" "))); }
      if (i === expect.length - 1) { sock.write("QUIT\r\n"); sock.end(); return resolve(); }
      sock.write(send[i] + (i === 7 ? "\r\n.\r\n" : "\r\n"));
      i++;
    });
  });
}

function handleContact(req, res) {
  if (limited(req.socket.remoteAddress)) return sendJSON(res, 429, { ok: false, error: "Too many messages. Please wait a minute." });
  let body = "";
  req.on("data", (c) => { body += c; if (body.length > 10000) req.destroy(); });
  req.on("end", async () => {
    let m;
    try { m = JSON.parse(body); } catch { return sendJSON(res, 400, { ok: false, error: "Invalid request." }); }
    if (m.website) return sendJSON(res, 200, { ok: true }); // hidden spam-trap field
    const name = String(m.name || "").trim().slice(0, 80);
    const email = String(m.email || "").trim().slice(0, 120);
    const message = String(m.message || "").trim().slice(0, 2000);
    if (!name || !message || !/^\S+@\S+\.\S+$/.test(email)) {
      return sendJSON(res, 400, { ok: false, error: "Please fill in your name, a valid email, and a message." });
    }

    // 1) Always keep a copy in messages.json
    let list = [];
    try { list = JSON.parse(fs.readFileSync(MESSAGES, "utf8")); } catch {}
    list.push({ time: new Date().toISOString(), name, email, message });
    try { fs.writeFileSync(MESSAGES, JSON.stringify(list, null, 2)); }
    catch { return sendJSON(res, 500, { ok: false, error: "Could not save your message." }); }
    console.log("New message from " + name + " <" + email + ">");

    // 2) Forward to Gmail when the App Password is set in config.json
    const cfg = loadConfig();
    const pass = String(cfg.gmailAppPassword || "").replace(/\s/g, "");
    if (cfg.gmailUser && pass) {
      try {
        await sendMail({
          user: cfg.gmailUser, pass, to: cfg.sendTo || cfg.gmailUser, replyTo: email,
          subject: ("Portfolio message from " + name).replace(/[\r\n]/g, " "),
          text: "Name: " + name + "\nEmail: " + email + "\n\n" + message,
        });
        console.log("  -> forwarded to Gmail");
      } catch (e) { console.log("  -> Gmail send failed: " + e.message); }
    } else {
      console.log("  -> Gmail not set up yet (add gmailAppPassword in config.json)");
    }
    sendJSON(res, 200, { ok: true });
  });
}

// ---- TaskFlow demo API: in-memory, private per visitor (X-Client header), capped ----
const tasksDB = new Map();
function readJSON(req, cb) {
  let b = "";
  req.on("data", (c) => { b += c; if (b.length > 2000) req.destroy(); });
  req.on("end", () => { try { cb(JSON.parse(b || "{}")); } catch { cb(null); } });
}
function handleTasks(req, res, url) {
  const cid = String(req.headers["x-client"] || "");
  if (!/^[a-z0-9-]{8,40}$/.test(cid)) return sendJSON(res, 400, { ok: false, error: "Missing client id" });
  if (!tasksDB.has(cid)) {
    if (tasksDB.size >= 500) tasksDB.delete(tasksDB.keys().next().value);
    tasksDB.set(cid, []);
  }
  let list = tasksDB.get(cid);
  const id = url.split("/")[3];
  if (req.method === "GET") return sendJSON(res, 200, list);
  if (req.method === "POST") {
    return readJSON(req, (b) => {
      const text = String((b && b.text) || "").trim().slice(0, 100);
      if (!text) return sendJSON(res, 400, { ok: false, error: "Task text is required" });
      if (list.length >= 50) return sendJSON(res, 400, { ok: false, error: "Demo limit: 50 tasks" });
      list.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text, done: false });
      sendJSON(res, 200, list);
    });
  }
  if (req.method === "PATCH" && id) {
    const t = list.find((x) => x.id === id);
    if (t) t.done = !t.done;
    return sendJSON(res, 200, list);
  }
  if (req.method === "DELETE") {
    list = id ? list.filter((x) => x.id !== id) : list.filter((x) => !x.done);
    tasksDB.set(cid, list);
    return sendJSON(res, 200, list);
  }
  sendJSON(res, 405, { ok: false, error: "Method not allowed" });
}

// ---- Visitor counter (saved in views.json) ----
const VIEWS = path.join(__dirname, "views.json");
let views = 0;
try { views = JSON.parse(fs.readFileSync(VIEWS, "utf8")).views || 0; } catch {}
const viewHits = new Map();
function handleViews(req, res) {
  if (req.method === "POST") {
    const ip = req.socket.remoteAddress, now = Date.now();
    const recent = (viewHits.get(ip) || []).filter((t) => now - t < 60000);
    recent.push(now);
    viewHits.set(ip, recent);
    if (recent.length <= 10) {
      views++;
      fs.writeFile(VIEWS, JSON.stringify({ views }), () => {});
    }
  }
  sendJSON(res, 200, { views });
}

http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split("?")[0]);
  if (req.method === "POST" && url === "/api/contact") return handleContact(req, res);
  if (url === "/api/views") return handleViews(req, res);
  if (url === "/api/tasks" || url.startsWith("/api/tasks/")) return handleTasks(req, res, url);

  if (url === "/api/profile") {
    fs.readFile(path.join(__dirname, "data.json"), (err, data) => {
      if (err) { res.writeHead(500); return res.end("Cannot read data.json"); }
      res.writeHead(200, { "Content-Type": TYPES[".json"] });
      res.end(data);
    });
    return;
  }

  const file = path.normalize(path.join(PUBLIC, url === "/" ? "index.html" : url));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end("Not found"); }
    const type = TYPES[path.extname(file)] || "application/octet-stream";
    const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || "");
    let start = 0, end = st.size - 1, code = 200;
    if (range) {
      start = range[1] ? +range[1] : 0;
      end = range[2] ? Math.min(+range[2], st.size - 1) : st.size - 1;
      if (start > end || start >= st.size) { res.writeHead(416, { "Content-Range": "bytes */" + st.size }); return res.end(); }
      code = 206;
    }
    const head = { "Content-Type": type, "Accept-Ranges": "bytes", "Content-Length": end - start + 1 };
    if (code === 206) head["Content-Range"] = "bytes " + start + "-" + end + "/" + st.size;
    res.writeHead(code, head);
    if (req.method === "HEAD") return res.end();
    fs.createReadStream(file, { start, end }).on("error", () => res.end()).pipe(res);
  });
}).listen(PORT, () => console.log(`Portfolio running: http://localhost:${PORT}`));
